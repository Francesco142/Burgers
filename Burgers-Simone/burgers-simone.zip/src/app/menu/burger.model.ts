export interface Burger {
    id: number | "",
    title: string,
    bread: string,
    meat: string,
    ingredients: string[]
}